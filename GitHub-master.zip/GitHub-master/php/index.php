<?php
/**
 * Created by PhpStorm.
 * User: Gags
 * Date: 2016-11-09
 * Time: 7:56 PM
 */

echo 'Hello World edir!';
echo '2nd Hello World!';
