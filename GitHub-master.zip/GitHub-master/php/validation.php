<?php
/**
 * Created by PhpStorm.
 * User: Gags
 * Date: 2016-11-09
 * Time: 8:30 PM
 */
echo 'My validation';